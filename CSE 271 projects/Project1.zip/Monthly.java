import java.util.Calendar;
import java.util.GregorianCalendar;

public class Monthly extends Appointment 
{
	private String description;
	
	private GregorianCalendar calendar;
	
	public Monthly(String des, GregorianCalendar cal)
	{
		description=des;
		calendar = cal;
		
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getType()
	{
		return 2;
	}
	public GregorianCalendar getCalendar() {
		return calendar;
	}
	public boolean occursOn(int day, int month, int year) 
	{
		GregorianCalendar testcal = new GregorianCalendar(year,month,day);
		
		if(calendar.compareTo(testcal)==-1)
		{
			return false;
		}
		if(calendar.get(Calendar.DATE)==day)
		{
			return true;
		}
		else
		{
			return false;

		}
	}

}
