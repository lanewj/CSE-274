//import java.util.Calendar;
import java.util.GregorianCalendar;

public class Daily extends Appointment 
{

	private String description;
	private GregorianCalendar calendar;
	
	public Daily(String des, GregorianCalendar cal)
	{
		description=des;
		calendar = cal;
	}
	public String getDescription() 
	{
		return description;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}
	public int getType()
	{
		return 3;
	}
	public GregorianCalendar getCalendar() {
		return calendar;
	}
	public boolean occursOn(int day, int month, int year)
	{
		GregorianCalendar testcal = new GregorianCalendar(year,month,day);
		
		if(calendar.compareTo(testcal)>-1)
		{
			return true;
		}
		return false;
	}
	
	
	
	
}
