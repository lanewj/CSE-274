//import java.util.Calendar;
import java.util.GregorianCalendar;

public abstract class Appointment 
{

	public abstract boolean occursOn(int day, int month, int year);
	{

		
	}
	public abstract int getType();
	public abstract String getDescription();
	//public abstract int getDay();
	//public abstract int getMonth();
	//public abstract int getYear();
	public abstract GregorianCalendar getCalendar();
	
	
	
	
	
}
