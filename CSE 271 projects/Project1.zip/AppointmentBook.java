import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class AppointmentBook //implements Appointment
{
	private ArrayList<Appointment> book = new ArrayList<Appointment>();

	final static int ONETIME =1;
	final static int MONTHLY =2;
	final static int DAILY =3;

	
	// if num = 1, onetime if num = 2, monthly if num=3 daily
	public void addAppointment(int num, String description, GregorianCalendar cal ) throws NullPointerException
	{
		
		if(num==ONETIME)
		{
			Appointment o = new OneTime(description, cal); 
			book.add(o);	
		}
		if(num==MONTHLY)
		{
			Appointment m = new Monthly(description,cal); 
			book.add(m);		
		}
		if(num==DAILY)
		{
			Appointment d = new Daily(description, cal); 
			book.add(d);
		}
	
	}
	public static void save(Appointment a, String doc) throws FileNotFoundException
	{
		PrintWriter PW = new PrintWriter(new File(doc));
		GregorianCalendar cal = a.getCalendar();
		
		
		PW.println(a.getType());
		PW.println(a.getDescription());
		PW.println(cal.get(Calendar.DATE));
		PW.println(cal.get(Calendar.MONTH));
		PW.println(cal.get(Calendar.YEAR));
		
		PW.close();
		//Delimiter
		
	}
	public void load(File doc) throws FileNotFoundException
	{	
		Scanner in = new Scanner(doc);
		
		int type = Integer.parseInt(in.nextLine());
		String description = in.nextLine();
		int day = Integer.parseInt(in.nextLine());
		int month = Integer.parseInt(in.nextLine());
		int year = Integer.parseInt(in.nextLine());
		
		GregorianCalendar cal = new GregorianCalendar(year,month,day);
		
		addAppointment(type, description, cal);
		
		in.close();		
	}
	
	
	
	
	
	
	
	
}
