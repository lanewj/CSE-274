//import java.io.File;
import java.io.FileNotFoundException;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class AppointmentTest {

	public static void main(String[] args) throws NullPointerException , FileNotFoundException   
	{
		
		AppointmentBook journal = new AppointmentBook();
		
		GregorianCalendar cala = new GregorianCalendar(2013,8,9);
		Appointment a = new OneTime("go to moms birthday party", cala);
		GregorianCalendar calb = new GregorianCalendar(2012,10,15);
		Appointment b = new Monthly("yoga", calb);
		GregorianCalendar calc = new GregorianCalendar(2012,10,1);
		Appointment c = new Daily("go to gym", calc);
		GregorianCalendar cald = new GregorianCalendar(2013,5,10);
		Appointment d = new OneTime("Chris's wedding", cald);
		
		journal.addAppointment(a.getType(), a.getDescription(), cala );
		journal.addAppointment(b.getType(), b.getDescription(), calb );
		journal.addAppointment(c.getType(), c.getDescription(), calc );
		//journal.addAppointment(d.getType(), d.getDescription(), cald );
		
		
		Boolean aret = a.occursOn(cala.get(Calendar.DATE), cala.get(Calendar.MONTH),cala.get(Calendar.YEAR));
		
		Boolean bret = b.occursOn(calb.get(Calendar.DATE), calb.get(Calendar.MONTH),calb.get(Calendar.YEAR));
		
		Boolean cret = c.occursOn(calc.get(Calendar.DATE), calc.get(Calendar.MONTH),calc.get(Calendar.YEAR));
		
		//Boolean dret = d.occursOn(cald.get(Calendar.DATE), cald.get(Calendar.MONTH),cald.get(Calendar.YEAR));
		
		System.out.println("Test for oneTime should true" + "test: " + aret);
		System.out.println("Test for oneTime should true" + "test: " + bret);
		System.out.println("Test for oneTime should true" + "test: " + cret);
		
		
		AppointmentBook.save(d,"txt.txt");
		
		
		
		//journal.load((File)("txt.txt"));
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
