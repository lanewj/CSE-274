//import java.util.Calendar;
import java.util.GregorianCalendar;

public class OneTime extends Appointment
{
	private GregorianCalendar calendar;
	private String description;
	public OneTime(String des, GregorianCalendar cal)
	{
	
	description = des;
	calendar = cal;
	
	}
	public String getDescription() 
	{
		return description;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}
	public int getType()
	{
		return 1;
	}
	public GregorianCalendar getCalendar()
	{
		return calendar;
	}
	public boolean occursOn(int day, int month, int year)
	{
GregorianCalendar testcal = new GregorianCalendar(year,month,day);
		
		if(calendar.compareTo(testcal)==0)
		{
			return true;
		}
		return false;
	}
	
	 
	
	
	
	
	
	
	
	
	
	
	
	
}
