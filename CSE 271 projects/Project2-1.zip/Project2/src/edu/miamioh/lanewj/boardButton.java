package edu.miamioh.lanewj;

import java.awt.Color;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class boardButton extends JButton
{
	//private String Colour;
	private boolean queen;
	private ImageIcon transparent = new ImageIcon(new BufferedImage(64,64, BufferedImage.TYPE_INT_ARGB));
	private ImageIcon imag = new ImageIcon("queen2.jpg");
	private int row;
	private int col;
	
	public boardButton(String color, int r,  int c)
	{
		
		queen=false;
		row=r;
		col=c;
		//this.setIcon(imag);

		if(color.equals("w"))
		{
			this.setBackground(Color.BLACK);
			this.setOpaque(true);
		}
		else
		{
			this.setBackground(Color.WHITE);
			this.setOpaque(true);
		}
	}
	public int getRow()
	{
		return row;
	}
	public int getCol()
	{
		return col;
	}
	public boolean clicked()
	{
		if(queen==true)
		{
			setIcon(transparent);
			
			queen=false;
			return false;
		}
		else
		{
			setIcon(imag);
			queen=true;
			return true;
		
		}
	}
	public boolean isClicked()
	{
		return queen;
		
	}

}
