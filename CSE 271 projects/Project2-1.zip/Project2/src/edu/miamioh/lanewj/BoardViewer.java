/**
 * 
 */
package edu.miamioh.lanewj;

import javax.swing.JFrame;

/**
 * @author lanewj
 *
 */
public class BoardViewer {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		JFrame frame = new Board();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("converter");

		frame.setVisible(true);
	}

}