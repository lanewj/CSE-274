package edu.miamioh.lanewj;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

//import edu.miamioh.Lanewj.Converter.CalcListner;

public class Board extends JFrame {
	private static final int FRAME_WIDTH = 400;
	private static final int FRAME_HEIGHT = 450;
	private JPanel main;
	private JPanel subPanel;
	private JPanel subPanel2;
	private JButton hint;
	private JButton corr;
	private int count = 0;
	private boardButton[][] buttons;
	private ArrayList<boardButton> queens = new ArrayList<boardButton>();
	private boolean ret;
	private JLabel label;

	public Board() 
	{
		createPanel();
		createButtons();

		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
	}

	private void createButtons() {
		// ImageIcon icon = new ImageIcon(BufferedImage(64,64,
		// BufferedImage.TYPE_INT_ARGB));
		
		ActionListener corl = new checkListener();
		buttons = new boardButton[8][8];
		hint = new JButton("Hint");
		ActionListener hinl = new hintListener();
		boardButton button;
		hint.addActionListener(hinl);
		subPanel2.add(hint, BorderLayout.EAST);
		
		

		corr = new JButton("Check");
		corr.addActionListener(corl);
		subPanel2.add(corr, BorderLayout.WEST);
		
		label = new JLabel();
		subPanel2.add(label, BorderLayout.CENTER);
			

		int count = 0;
		ActionListener list = new QListener();

		for (int r = 0; r < 8; r++) {
			for (int c = 0; c < 8; c++) {

				if (count % 2 == 0) {
					button = new boardButton("b", r, c);

				} else {
					button = new boardButton("w", r, c);
				}
				button.addActionListener(list);
				subPanel.add(button);
				buttons[r][c] = button;
				count++;
			}
			count++;
		}

	}

	public void createPanel() {

		main = new JPanel();
		main.setLayout(new BorderLayout());

		subPanel = new JPanel();
		subPanel.setLayout(new GridLayout(8, 8));

		subPanel2 = new JPanel();
		subPanel2.setLayout(new BorderLayout());

		main.add(subPanel, BorderLayout.CENTER);
		main.add(subPanel2, BorderLayout.SOUTH);
		this.add(main);
	}

	class QListener implements ActionListener 
	{

		public void actionPerformed(ActionEvent e) 
		{

			boardButton button = (boardButton) e.getSource();
			// boolean bla = button.clicked();
			if (count < 8) 
			{
				if (button.clicked()) 
				{
					count++;
					queens.add(button);
					//System.out.println(queens.size());
				} 
				else 
				{
					count--;
					queens.remove(button);
					//System.out.println(queens.size());
				}
			}
			else if (button.isClicked())
			{
				button.clicked();
				count--;
			}
		}
		
	}
	class hintListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent e) 
		{
			//System.out.print("asdasasD");
			int[][] board = new int[8][8];
			
			for(int i = 0; i<8; i++)
			{
				for(int w=0; w<8 ; w++)
				{
					board[i][w]=1;
				}
				//System.out.print("asdasasD");
			}
			for (int q=0; q<queens.size();q++) 
			{
				for(int r=0; r<8 ; r++)
				{
					board[r][queens.get(q).getCol()]=0;
				}
			}
			for (int q=0; q<queens.size();q++)
			{
				for(int c=0; c<8 ; c++)
				{
					board[queens.get(q).getRow()][c]=0;
				}
			}
			for (int q=0; q<queens.size();q++)
			{
				for( int ro=queens.get(q).getCol(); ro<8; ro++)
				{
					//for( int co=0; co<8; co++)
					//{
						board[Math.abs(queens.get(q).getRow()-ro)][Math.abs(queens.get(q).getRow()-ro)]=0;
					//}
				}
			}
			
			for (int row = 0; row < 8 ; row++) 
			{
			    for (int col = 0; col < 8; col++)
			    {
			    	if(board[row][col]==1)
			    	{
			    		label.setText(" ( " + (row + 1) + " , "  + (col + 1) + " )" );
			    		 row=7;
			    	}
			    } 
			   
			}
			
			for (int row = 0; row < 8 ; row++) 
			{
			    for (int col = 0; col < 8; col++)
			    {
			        //System.out.print(board[row][col] + " ");
			    }
			    System.out.println();
			    
			}
			
			
			
			
			
			
			
			if(count==8)
			{
				label.setText("8 QUEENS ON THE BOARD");
			}

		}
	}
	class checkListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent e) 
		{
			ret=false;
			/*
			for(int i=0; i<queens.size();i++)
			{
				System.out.println("(" + queens.get(i).getRow()+ " , " + queens.get(i).getCol() + ")");
				for(int r=0; r<8; r++)
				{
					for(int c=0; c<8; c++)
					{    //  
						if(queens.get(i).getRow()==r&&queens.get(i).getCol()==c)
						{
						}
						else
						{
							System.out.println(buttons[r][c].getRow()+" , "+buttons[r][c].getCol());
							
							if(buttons[r][c].isClicked()==true&&queens.get(i).getRow()==r||queens.get(i).getCol()==c)
									{
										System.out.println("true");
										ret=true;
									}
						}	
					}	
				}
				//System.out.println(ret);
			}
			
			System.out.println(ret);
			ret=false;*/
			
			for(int i=0;i<queens.size();i++)
			{
				for(int w=0; w<queens.size();w++)
				{
					//System.out.println(queens.get(i).getRow()+ " , " + queens.get(w).getRow() + " + " + queens.get(i).getCol() + " , " + queens.get(w).getCol());
					if(queens.get(i).getRow()==queens.get(w).getRow()&&queens.get(i).getCol()==queens.get(w).getCol())
					{
					}
					else if(queens.get(i).getRow()==queens.get(w).getRow()||queens.get(i).getCol()==queens.get(w).getCol())
					{
						ret=true;
						label.setText("Coordinates : ( " + (queens.get(i).getRow() + 1 ) + " , " +
								(queens.get(i).getCol()+1) + " ) and ( "  + (queens.get(i).getRow() + 1 ) + " , "  + (queens.get(i).getCol()+1) + " )");
						i=queens.size()-1;
					}
					else if(Math.abs(queens.get(i).getRow()-queens.get(w).getRow())==Math.abs(queens.get(i).getCol()-queens.get(w).getCol()))
					{
						ret=true;
						label.setText("Coordinates : ( " + (queens.get(i).getRow() + 1 ) + " , " +
								(queens.get(i).getCol()+1) + " ) and ( "  + (queens.get(i).getRow() + 1 ) + " , "  + (queens.get(i).getCol()+1) + " )");
						i=queens.size()-1;
					}
					
				}
			}
			
			if(ret==true)
			{
				label.setText("Queens are not safe");
			}
			else
			{
				label.setText("Queens are safe");	
			}
		
			

		}

	}
}
